"""
================================================================================
MODELO ELECTORAL ARGENTINA v5 — PRODUCCIÓN
================================================================================

Modelo de fundamentals para pronóstico del voto al oficialismo en elecciones
nacionales (presidenciales y legislativas). Muestra pooled n=16 (2003-2025).

Especificación final:
    Oficialismo_t = β0 + β1·ICG²(6m)_t + β2·log(1 + IPC_mom(6m)_t) + ε_t

Donde:
    ICG²(6m)         : promedio del Índice de Confianza en el Gobierno (UTDT)
                       en los 6 meses previos a la elección, al cuadrado.
                       La transformación cuadrática captura la convexidad:
                       a niveles altos de confianza, cada punto adicional
                       mueve más votos.
    log(1+IPC_mom)   : log-transformación de la inflación mensual promedio
                       de los 6 meses previos. Atenúa el efecto desproporcionado
                       de la hiperinflación en el ajuste lineal.

Cambios respecto a v4:
    - Se elimina la dummy presidencial (no significativa, p=0.25 en v4)
    - Se reemplaza IPC_mom lineal por log(1+IPC_mom)
    - Resultado: MAE LOO baja de 3.64 a 3.26 pp (-10%)
    - R² ajustado se mantiene (0.68 → 0.67), pero todos los coefs p<0.05

Modelos descartados en la búsqueda:
    - ICG² + ICC² + salario_real (MAE 2.63 pp): signo invertido en salario
      real → efecto de supresión, no señal económica genuina
    - ICG + IPC² + brecha (MAE 2.96 pp): signo invertido en IPC²
    - ICG + IPC_mom + brecha (MAE 3.16 pp): brecha no significativa (p=0.17)

Performance (LOO-CV):
    MAE       : 3.26 pp
    RMSE      : 4.15 pp
    Skill     : +34.5% vs naïve por tipo
    R²        : 0.714
    R² ajust. : 0.670

Validación OOS pura en 2025 (entreno hasta 2023, predigo 2025):
    Ver salida del script.

Autor   : Ruben + Claude
Versión : v5.0 (parsimonioso + log-IPC, mayo 2026)
================================================================================
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass

import numpy as np
import pandas as pd
import statsmodels.api as sm
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import LeaveOneOut
from statsmodels.stats.outliers_influence import variance_inflation_factor

warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=FutureWarning)


# ============================================================================
# CONFIGURACIÓN
# ============================================================================

CONFIG = {
    'data_path'        : 'base_elecciones.xlsx',
    'sheet_macro'      : 'base',
    'sheet_elecciones' : 'elecciones',
    'ventana_meses'    : 6,
    'alpha_ic'         : 0.10,
    'excluir_balotajes': True,
    'excluir_2003_leg' : True,
    'n_bootstrap'      : 2000,
}

FECHAS_ELECCIONES = {
    0:  ('2003-04-30', 'presidencial', 'Néstor Kirchner (sin balotaje)'),
    1:  ('2007-10-31', 'presidencial', 'CFK 2007'),
    2:  ('2011-10-31', 'presidencial', 'CFK 2011'),
    3:  ('2015-10-31', 'presidencial', 'Scioli (generales 1ra vuelta)'),
    4:  ('2015-11-30', 'presidencial', 'Scioli (balotaje) — EXCLUIDO'),
    5:  ('2019-10-31', 'presidencial', 'Macri 2019'),
    6:  ('2023-10-31', 'presidencial', 'Massa (generales 1ra vuelta)'),
    7:  ('2023-11-30', 'presidencial', 'Massa (balotaje) — EXCLUIDO'),
    8:  ('2003-10-31', 'legislativa',  'PJ-Duhalde — EXCLUIDO (transición)'),
    9:  ('2005-10-31', 'legislativa',  'FpV 2005'),
    10: ('2007-10-31', 'legislativa',  'FpV 2007 (concurrente con pres.)'),
    11: ('2009-10-31', 'legislativa',  'FpV 2009 (derrota Kirchner)'),
    12: ('2011-10-31', 'legislativa',  'FpV 2011 (concurrente)'),
    13: ('2013-10-31', 'legislativa',  'FpV 2013'),
    14: ('2015-10-31', 'legislativa',  'FpV 2015 (concurrente)'),
    15: ('2017-10-31', 'legislativa',  'Cambiemos 2017'),
    16: ('2019-10-31', 'legislativa',  'FdT 2019 (concurrente)'),
    17: ('2021-10-31', 'legislativa',  'FdT 2021 (derrota)'),
    18: ('2023-10-31', 'legislativa',  'UxP 2023 (concurrente)'),
    19: ('2025-10-31', 'legislativa',  'LLA 2025'),
}

# Features del modelo (las TRANSFORMADAS)
FEATURES = ['icg_6m_sq', 'log_ipc_6m']


# ============================================================================
# CARGA Y PREPARACIÓN
# ============================================================================

def cargar_datos(path: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Carga las dos hojas del archivo de inputs."""
    df_base = pd.read_excel(path, sheet_name=CONFIG['sheet_macro'])
    df_base['Dates'] = pd.to_datetime(df_base['Dates'])
    df_base = df_base.sort_values('Dates').reset_index(drop=True)

    df_elec = pd.read_excel(path, sheet_name=CONFIG['sheet_elecciones'])
    df_elec['fecha']    = pd.to_datetime([FECHAS_ELECCIONES[i][0] for i in df_elec.index])
    df_elec['tipo']     = [FECHAS_ELECCIONES[i][1] for i in df_elec.index]
    df_elec['etiqueta'] = [FECHAS_ELECCIONES[i][2] for i in df_elec.index]
    return df_base, df_elec


def features_pre_eleccion(fecha_elec: pd.Timestamp,
                           df_base: pd.DataFrame,
                           ventana: int = 6) -> dict | None:
    """Promedia macro en los `ventana` meses previos al mes de la elección."""
    cutoff_end   = fecha_elec - pd.DateOffset(months=1)
    cutoff_start = cutoff_end - pd.DateOffset(months=ventana - 1)
    mask = (df_base['Dates'] >= cutoff_start) & (df_base['Dates'] <= cutoff_end)
    sub  = df_base.loc[mask]
    if len(sub) < ventana - 1:
        return None
    return {
        'icg_6m'       : sub['icg'].mean(),
        'ipc_mom_6m'   : sub['ipc_mom'].mean(),
        'icc_6m'       : sub['icc'].mean(),
        'emae_yoy_6m'  : sub['EMAE_yoy'].mean(),
        'n_obs_ventana': len(sub),
    }


def construir_dataset(df_base: pd.DataFrame, df_elec: pd.DataFrame) -> pd.DataFrame:
    """Une elecciones con features macro pre-electorales y aplica transformaciones."""
    rows = []
    for idx, row in df_elec.iterrows():
        f = features_pre_eleccion(row['fecha'], df_base, CONFIG['ventana_meses'])
        if f is None:
            continue
        f.update({
            'año'        : int(row['año']),
            'tipo'       : row['tipo'],
            'etiqueta'   : row['etiqueta'],
            'fecha'      : row['fecha'],
            'Oficialismo': row['Oficialismo'],
            'Oposicion1' : row['Oposición 1'],
        })
        rows.append(f)

    df = pd.DataFrame(rows)

    if CONFIG['excluir_balotajes']:
        balotajes = [pd.Timestamp('2015-11-30'), pd.Timestamp('2023-11-30')]
        df = df[~df['fecha'].isin(balotajes)]

    if CONFIG['excluir_2003_leg']:
        df = df[~((df['año'] == 2003) & (df['tipo'] == 'legislativa'))]

    # === TRANSFORMACIONES DEL MODELO v5 ===
    df['icg_6m_sq']  = df['icg_6m'] ** 2
    df['log_ipc_6m'] = np.log1p(df['ipc_mom_6m'])

    return df.sort_values('fecha').reset_index(drop=True)


# ============================================================================
# AJUSTE Y VALIDACIÓN
# ============================================================================

@dataclass
class ResultadoValidacion:
    mae_loo: float
    rmse_loo: float
    mae_naive_global: float
    mae_naive_por_tipo: float
    skill_vs_naive_tipo: float
    r2: float
    r2_adj: float
    aic: float
    bic: float
    durbin_watson: float
    vif: dict
    n: int
    predicciones_loo: np.ndarray
    df_errores: pd.DataFrame
    oos_2025: dict
    bootstrap_estabilidad: dict


def ajustar_modelo(df: pd.DataFrame):
    X = sm.add_constant(df[FEATURES])
    y = df['Oficialismo']
    return sm.OLS(y, X).fit()


def loo_cv(df: pd.DataFrame) -> tuple[float, float, np.ndarray]:
    X = sm.add_constant(df[FEATURES])
    y = df['Oficialismo']
    preds = np.zeros(len(df))
    for tr, te in LeaveOneOut().split(X):
        m = sm.OLS(y.iloc[tr], X.iloc[tr]).fit()
        preds[te] = m.predict(X.iloc[te]).iloc[0]
    mae  = mean_absolute_error(y, preds) * 100
    rmse = np.sqrt(np.mean((y.values - preds) ** 2)) * 100
    return mae, rmse, preds


def validar_oos_2025(df: pd.DataFrame) -> dict:
    df_tr = df[df['año'] < 2025]
    df_te = df[df['año'] == 2025]
    if len(df_te) == 0:
        return {'disponible': False}

    X_tr = sm.add_constant(df_tr[FEATURES])
    y_tr = df_tr['Oficialismo']
    m    = sm.OLS(y_tr, X_tr).fit()

    X_te = sm.add_constant(df_te[FEATURES], has_constant='add')
    pred = m.predict(X_te).iloc[0]
    real = df_te['Oficialismo'].iloc[0]
    ci   = m.get_prediction(X_te).summary_frame(alpha=CONFIG['alpha_ic'])
    lo, hi = ci['obs_ci_lower'].iloc[0], ci['obs_ci_upper'].iloc[0]

    return {
        'disponible'     : True,
        'n_entrenamiento': len(df_tr),
        'predicho'       : pred,
        'real'           : real,
        'error_pp'       : (real - pred) * 100,
        'ic_lower'       : lo,
        'ic_upper'       : hi,
        'dentro_de_ic'   : bool(lo <= real <= hi),
    }


def bootstrap_coefs(df: pd.DataFrame, n_iter: int = 2000) -> dict:
    """Estabilidad de coeficientes por bootstrap."""
    X = sm.add_constant(df[FEATURES])
    y = df['Oficialismo']
    m_orig = sm.OLS(y, X).fit()

    rng = np.random.default_rng(seed=42)
    coefs = {p: [] for p in m_orig.params.index}
    for _ in range(n_iter):
        idx = rng.choice(len(df), len(df), replace=True)
        try:
            m = sm.OLS(y.iloc[idx], X.iloc[idx]).fit()
            for p in coefs:
                coefs[p].append(m.params[p])
        except Exception:
            continue

    out = {}
    for p, vals in coefs.items():
        arr = np.array(vals)
        signo_orig = np.sign(m_orig.params[p])
        out[p] = {
            'coef_orig'       : float(m_orig.params[p]),
            'media_bootstrap' : float(arr.mean()),
            'std_bootstrap'   : float(arr.std()),
            'ic_lower_95'     : float(np.percentile(arr, 2.5)),
            'ic_upper_95'     : float(np.percentile(arr, 97.5)),
            'pct_mismo_signo' : float(np.mean(np.sign(arr) == signo_orig) * 100),
        }
    return out


def calcular_vif(df: pd.DataFrame) -> dict:
    X = sm.add_constant(df[FEATURES])
    return {f: float(variance_inflation_factor(X.values, i + 1))
            for i, f in enumerate(FEATURES)}


def validar(df: pd.DataFrame) -> ResultadoValidacion:
    modelo = ajustar_modelo(df)
    mae_loo, rmse_loo, preds = loo_cv(df)

    y = df['Oficialismo']
    mae_naive_global   = mean_absolute_error(y, [y.mean()] * len(y)) * 100
    naive_por_tipo     = df.groupby('tipo')['Oficialismo'].transform('mean')
    mae_naive_por_tipo = mean_absolute_error(y, naive_por_tipo) * 100
    skill              = (mae_naive_por_tipo - mae_loo) / mae_naive_por_tipo * 100

    df_err = df[['año', 'tipo', 'etiqueta', 'Oficialismo']].copy()
    df_err['pred_loo'] = preds
    df_err['error_pp'] = (df_err['Oficialismo'] - df_err['pred_loo']) * 100
    df_err = df_err.sort_values('error_pp', key=abs, ascending=False)

    return ResultadoValidacion(
        mae_loo               = mae_loo,
        rmse_loo              = rmse_loo,
        mae_naive_global      = mae_naive_global,
        mae_naive_por_tipo    = mae_naive_por_tipo,
        skill_vs_naive_tipo   = skill,
        r2                    = modelo.rsquared,
        r2_adj                = modelo.rsquared_adj,
        aic                   = modelo.aic,
        bic                   = modelo.bic,
        durbin_watson         = float(sm.stats.durbin_watson(modelo.resid)),
        vif                   = calcular_vif(df),
        n                     = len(df),
        predicciones_loo      = preds,
        df_errores            = df_err.reset_index(drop=True),
        oos_2025              = validar_oos_2025(df),
        bootstrap_estabilidad = bootstrap_coefs(df, CONFIG['n_bootstrap']),
    )


# ============================================================================
# PRONÓSTICO
# ============================================================================

def pronosticar(modelo, icg_6m: float, ipc_mom_6m: float,
                alpha: float = 0.10) -> dict:
    """Pronóstico con un par de inputs (ICG promedio 6m, IPC mom promedio 6m)."""
    X = pd.DataFrame([{
        'const'     : 1.0,
        'icg_6m_sq' : icg_6m ** 2,
        'log_ipc_6m': np.log1p(ipc_mom_6m),
    }])
    pred = float(modelo.predict(X).iloc[0])
    ci   = modelo.get_prediction(X).summary_frame(alpha=alpha)
    return {
        'punto'   : pred,
        'ic_lower': float(ci['obs_ci_lower'].iloc[0]),
        'ic_upper': float(ci['obs_ci_upper'].iloc[0]),
        'inputs'  : {'icg_6m': icg_6m, 'ipc_mom_6m': ipc_mom_6m},
    }


def grilla_escenarios_2027(modelo) -> pd.DataFrame:
    """Pronóstico oct-2027 sobre una grilla 2D de ICG x IPC_mom."""
    icgs = [1.3, 1.5, 1.7, 2.0, 2.3, 2.5, 2.7]
    ipcs = [0.010, 0.015, 0.020, 0.025, 0.030]
    rows = []
    for icg in icgs:
        for ipc in ipcs:
            r = pronosticar(modelo, icg, ipc, CONFIG['alpha_ic'])
            rows.append({
                'icg_6m'     : icg,
                'ipc_mom_6m' : ipc,
                'pronostico' : r['punto'],
                'ic_lower'   : r['ic_lower'],
                'ic_upper'   : r['ic_upper'],
            })
    return pd.DataFrame(rows)


def escenarios_narrativos_2027(modelo) -> pd.DataFrame:
    """Pronóstico oct-2027 en 5 escenarios narrativos."""
    grid = [
        ('Pesimista',     'Deterioro de confianza + inflación al alza',  1.5, 0.025),
        ('Base bajo',     'Continuidad pero erosión leve',               1.8, 0.020),
        ('Base',          'Continuidad situación actual (ICG abr-2026)', 2.0, 0.018),
        ('Optimista',     'Confianza repunta + desinflación',            2.4, 0.015),
        ('Récord',        'ICG en máximo histórico',                     2.6, 0.012),
    ]
    rows = []
    for nombre, desc, icg, ipc in grid:
        r = pronosticar(modelo, icg, ipc, CONFIG['alpha_ic'])
        rows.append({
            'escenario'   : nombre,
            'descripcion' : desc,
            'icg_6m_asum' : icg,
            'ipc_mom_asum': ipc,
            'pronostico'  : r['punto'],
            'ic_lower'    : r['ic_lower'],
            'ic_upper'    : r['ic_upper'],
            'gana_1ra'    : r['punto'] >= 0.45,  # umbral aproximado AR
        })
    return pd.DataFrame(rows)


def umbrales_de_ganancia(modelo, ipc_supuesto: float = 0.018) -> pd.DataFrame:
    """
    Dado un IPC mensual fijo, calcula el ICG promedio 6m necesario para
    alcanzar distintos umbrales de voto.
    """
    log_ipc = np.log1p(ipc_supuesto)
    b0 = modelo.params['const']
    b1 = modelo.params['icg_6m_sq']
    b2 = modelo.params['log_ipc_6m']

    # voto = b0 + b1 * icg² + b2 * log_ipc
    # → icg = sqrt((voto - b0 - b2*log_ipc) / b1)
    umbrales = [0.40, 0.45, 0.50, 0.55]
    rows = []
    for v in umbrales:
        rhs = (v - b0 - b2 * log_ipc) / b1
        icg_req = float(np.sqrt(rhs)) if rhs > 0 else None
        rows.append({
            'umbral_voto'  : v,
            'icg_6m_requerido': icg_req,
            'comentario'   : 'No alcanzable con coefs actuales' if icg_req is None else '',
        })
    return pd.DataFrame(rows)


# ============================================================================
# REPORTING
# ============================================================================

def print_header(text: str, char: str = '=') -> None:
    print()
    print(char * 78)
    print(text)
    print(char * 78)


def fmt_pct(x: float, dec: int = 1) -> str:
    return f"{x*100:.{dec}f}%"


def reporte_validacion(modelo, res: ResultadoValidacion) -> None:
    print_header('MODELO ELECTORAL ARGENTINA v5 — REPORTE DE VALIDACIÓN')
    print(f"Especificación  : Oficialismo = β0 + β1·ICG²(6m) + β2·log(1+IPC_mom(6m))")
    print(f"Muestra         : n = {res.n} elecciones nacionales (2003-2025)")
    print(f"Variable target : % voto al oficialismo (1ra vuelta)")

    print_header('1. COEFICIENTES DEL MODELO', '-')
    print(modelo.summary().tables[1])
    print()
    print(f"R²              : {res.r2:.4f}")
    print(f"R² ajustado     : {res.r2_adj:.4f}")
    print(f"F-stat          : {modelo.fvalue:.3f}  (p = {modelo.f_pvalue:.5f})")
    print(f"AIC             : {res.aic:.2f}")
    print(f"BIC             : {res.bic:.2f}")
    print(f"Durbin-Watson   : {res.durbin_watson:.3f}  (≈2 → sin autocorrelación)")

    print_header('2. DIAGNÓSTICO DE MULTICOLINEALIDAD (VIF)', '-')
    print(f"Regla: VIF < 5 OK | 5-10 alerta | >10 grave")
    for f, vif in res.vif.items():
        flag = '✓' if vif < 5 else '⚠️' if vif < 10 else '✗'
        print(f"  {f:20s}: {vif:6.2f}  {flag}")

    print_header('3. ESTABILIDAD POR BOOTSTRAP (n=2000)', '-')
    print(f"{'Parámetro':<15} {'Coef':>10} {'Boot mean':>10} {'IC 95%':<22} {'% signo':>8}")
    for p, info in res.bootstrap_estabilidad.items():
        ic = f"[{info['ic_lower_95']:+.4f}, {info['ic_upper_95']:+.4f}]"
        print(f"{p:<15} {info['coef_orig']:>+10.4f} {info['media_bootstrap']:>+10.4f} "
              f"{ic:<22} {info['pct_mismo_signo']:>7.1f}%")

    print_header('4. VALIDACIÓN LEAVE-ONE-OUT', '-')
    print(f"MAE  LOO-CV               : {res.mae_loo:.2f} pp")
    print(f"RMSE LOO-CV               : {res.rmse_loo:.2f} pp")
    print(f"MAE naïve (media global)  : {res.mae_naive_global:.2f} pp")
    print(f"MAE naïve (media por tipo): {res.mae_naive_por_tipo:.2f} pp")
    print(f"Skill vs naïve por tipo   : {res.skill_vs_naive_tipo:+.1f}%")

    print_header('5. VALIDACIÓN OUT-OF-SAMPLE PURA: LEGISLATIVA 2025', '-')
    oos = res.oos_2025
    if oos['disponible']:
        print(f"Entrenamiento  : n = {oos['n_entrenamiento']} (datos hasta 2023)")
        print(f"Predicho 2025  : {fmt_pct(oos['predicho'])}")
        print(f"Real 2025      : {fmt_pct(oos['real'])}")
        print(f"Error          : {oos['error_pp']:+.2f} pp")
        print(f"IC 90%         : [{fmt_pct(oos['ic_lower'])}, {fmt_pct(oos['ic_upper'])}]")
        veredicto = '✓ DENTRO del IC' if oos['dentro_de_ic'] else '✗ FUERA del IC'
        print(f"Veredicto      : {veredicto}")

    print_header('6. ERRORES LOO POR ELECCIÓN (ordenados por |error|)', '-')
    df_e = res.df_errores.copy()
    df_e['Oficialismo'] = df_e['Oficialismo'].apply(lambda x: f"{x*100:5.2f}%")
    df_e['pred_loo']    = df_e['pred_loo'].apply(   lambda x: f"{x*100:5.2f}%")
    df_e['error_pp']    = df_e['error_pp'].apply(   lambda x: f"{x:+6.2f}")
    print(df_e.to_string(index=False))


def reporte_pronostico(esc: pd.DataFrame, grilla: pd.DataFrame,
                        umbrales: pd.DataFrame) -> None:
    print_header('7. PRONÓSTICO ELECCIÓN OCT-2027 — ESCENARIOS NARRATIVOS')
    print("Supuesto: ICG e IPC_mom promediados abr-2027 a sep-2027")
    print("Nota: el modelo no distingue pres/leg (dummy no significativa en v4)")
    print()
    out = esc.copy()
    out['pronostico']   = out['pronostico'].apply(  lambda x: f"{x*100:5.1f}%")
    out['ic_lower']     = out['ic_lower'].apply(    lambda x: f"{x*100:5.1f}%")
    out['ic_upper']     = out['ic_upper'].apply(    lambda x: f"{x*100:5.1f}%")
    out['ipc_mom_asum'] = out['ipc_mom_asum'].apply(lambda x: f"{x*100:.1f}%")
    out['icg_6m_asum']  = out['icg_6m_asum'].apply( lambda x: f"{x:.2f}")
    out['gana_1ra']     = out['gana_1ra'].apply(    lambda x: '✓' if x else '—')
    print(out.to_string(index=False))

    print_header('8. GRILLA 2D — VOTO PRONOSTICADO POR (ICG, IPC_mom)', '-')
    pivot = grilla.pivot(index='icg_6m', columns='ipc_mom_6m', values='pronostico')
    pivot.columns = [f"IPC={c*100:.1f}%" for c in pivot.columns]
    pivot.index = [f"ICG={i:.2f}" for i in pivot.index]
    print((pivot * 100).round(1).astype(str) + '%')

    print_header('9. UMBRALES DE GANANCIA — ICG REQUERIDO POR % DE VOTO', '-')
    print("(asumiendo IPC mensual 1.8% promedio 6m previos)")
    print()
    out = umbrales.copy()
    out['umbral_voto'] = out['umbral_voto'].apply(lambda x: f"{x*100:.0f}%")
    out['icg_6m_requerido'] = out['icg_6m_requerido'].apply(
        lambda x: f"{x:.2f}" if x is not None else 'N/A'
    )
    print(out.to_string(index=False))


def reporte_lectura_estrategica(esc: pd.DataFrame, res: ResultadoValidacion) -> None:
    print_header('10. LECTURA ESTRATÉGICA')
    base = esc[esc['escenario'] == 'Base'].iloc[0]
    p, lo, hi = base['pronostico'], base['ic_lower'], base['ic_upper']

    msg = [
        f"Escenario base 2027: {fmt_pct(p)}  IC 90% [{fmt_pct(lo)}, {fmt_pct(hi)}]",
        "",
        "Lectura:",
        f"  • Con ICG=2.0 e IPC mensual 1.8%, el oficialismo entra en zona",
        f"    competitiva pero por debajo del umbral de 1ra vuelta directa.",
        f"  • Cada +0.2 puntos de ICG promedio 6m mueve el pronóstico ~3.5 pp",
        f"    (no-lineal: el efecto crece con el nivel de ICG).",
        f"  • Cada -0.5 pp de inflación mensual mueve el pronóstico ~0.8 pp.",
        f"    Mucho más sensible al ICG que a la inflación en niveles actuales.",
        "",
        "Implicancias para gestión de activos:",
        f"  • Trade direccional sobre voto solo defendible si ICG se mueve",
        f"    fuera del corredor 1.8-2.2. En ese rango el modelo no discrimina.",
        f"  • La elasticidad ICG-voto es la variable monitoreable más útil:",
        f"    el SARIMAX-ICG semanal/mensual debería ser el primer panel del",
        f"    dashboard de pre-electoral.",
        f"  • Sorpresas asimétricas: el modelo pierde precisión en hiperinflación",
        f"    (2023 sobreestimado en ~5 pp aun con log-transform). Para nowcasting",
        f"    en regímenes de IPC mensual >5%, complementar con encuestas.",
        "",
        "Limitaciones a comunicar al comité:",
        f"  • MAE LOO de {res.mae_loo:.2f} pp: error típico ±3-4 puntos.",
        f"    No comunicar punto sin intervalo.",
        f"  • IC 90% del escenario base abarca {(hi-lo)*100:.0f} puntos.",
        f"  • Outlier 2017 (-{abs(res.df_errores.iloc[0]['error_pp']):.1f} pp): falta variable de",
        f"    imagen presidencial. Prioridad #1 para v6.",
        f"  • Modelo no distingue presidencial de legislativa concurrente; los",
        f"    arrastres de coattail no están modelados.",
    ]
    print('\n'.join(msg))


# ============================================================================
# EXPORTACIÓN
# ============================================================================

def exportar_resultados(df: pd.DataFrame,
                         res: ResultadoValidacion,
                         esc: pd.DataFrame,
                         grilla: pd.DataFrame,
                         umbrales: pd.DataFrame,
                         modelo,
                         path: str = 'modelo_v5_outputs.xlsx') -> None:
    """Persiste resultados en Excel para distribución."""
    coef_df = pd.DataFrame({
        'coeficiente': modelo.params,
        'std_error'  : modelo.bse,
        't_stat'     : modelo.tvalues,
        'p_value'    : modelo.pvalues,
        'ic_lower'   : modelo.conf_int()[0],
        'ic_upper'   : modelo.conf_int()[1],
    })

    diag_df = pd.DataFrame({
        'metrica': [
            'n', 'R²', 'R² ajust.', 'F-stat', 'AIC', 'BIC', 'Durbin-Watson',
            'MAE LOO (pp)', 'RMSE LOO (pp)',
            'MAE naïve por tipo (pp)', 'Skill vs naïve (%)',
            'OOS 2025 — predicho (%)', 'OOS 2025 — real (%)',
            'OOS 2025 — error (pp)', 'OOS 2025 — dentro IC 90%',
        ],
        'valor': [
            res.n, res.r2, res.r2_adj, modelo.fvalue, res.aic, res.bic,
            res.durbin_watson, res.mae_loo, res.rmse_loo,
            res.mae_naive_por_tipo, res.skill_vs_naive_tipo,
            res.oos_2025['predicho']*100, res.oos_2025['real']*100,
            res.oos_2025['error_pp'], int(res.oos_2025['dentro_de_ic']),
        ],
    })

    vif_df = pd.DataFrame([
        {'feature': f, 'vif': v} for f, v in res.vif.items()
    ])

    boot_df = pd.DataFrame(res.bootstrap_estabilidad).T

    with pd.ExcelWriter(path, engine='openpyxl') as w:
        df.to_excel(            w, sheet_name='dataset',         index=False)
        coef_df.to_excel(       w, sheet_name='coeficientes')
        diag_df.to_excel(       w, sheet_name='diagnostico',     index=False)
        vif_df.to_excel(        w, sheet_name='vif',             index=False)
        boot_df.to_excel(       w, sheet_name='bootstrap')
        res.df_errores.to_excel(w, sheet_name='errores_loo',     index=False)
        esc.to_excel(           w, sheet_name='pronostico_esc',  index=False)
        grilla.to_excel(        w, sheet_name='pronostico_grilla',index=False)
        umbrales.to_excel(      w, sheet_name='umbrales',        index=False)

    print(f"\n→ Resultados exportados a: {path}")


# ============================================================================
# PIPELINE
# ============================================================================

def main():
    df_base, df_elec = cargar_datos(CONFIG['data_path'])
    df               = construir_dataset(df_base, df_elec)
    modelo           = ajustar_modelo(df)
    resultado        = validar(df)
    esc              = escenarios_narrativos_2027(modelo)
    grilla           = grilla_escenarios_2027(modelo)
    umbrales         = umbrales_de_ganancia(modelo, ipc_supuesto=0.018)

    reporte_validacion(modelo, resultado)
    reporte_pronostico(esc, grilla, umbrales)
    reporte_lectura_estrategica(esc, resultado)

    exportar_resultados(df, resultado, esc, grilla, umbrales, modelo)

    return {
        'modelo'    : modelo,
        'dataset'   : df,
        'validacion': resultado,
        'escenarios': esc,
        'grilla'    : grilla,
        'umbrales'  : umbrales,
    }


if __name__ == '__main__':
    main()
